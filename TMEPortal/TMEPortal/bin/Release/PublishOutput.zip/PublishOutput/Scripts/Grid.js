﻿


function myfunction() {

}
  $("#gridContainer").dxDataGrid({
    dataSource: weekData,
        allowColumnResizing: true,
    // columnAutoWidth: true,
    columns: [
        {
            dataField: "Articulo"
        },
        {
            dataField: "Desripcion"
        },
        {
            dataField: "Cantidad"
        },
        {
            dataField: "Clasificacion"
        },
        {
            dataField: "Color"
        },
        {
            dataField: "ColorCodigo"
        },
        {
            dataField: "Largo"
        },
        {
            dataField: "Ancho"
        },
        {
            dataField: "Modelo"
        }
            ],
    grouping: {
        //autoExpandAll: true,
    },
    filterRow: {
        visible: true,
        applyFilter: "auto"
    },
    searchPanel: {
        visible: true,
        width: 240,
        placeholder: "Buscar..."
    },
    headerFilter: {
        visible: true
    },
    loadPanel: {
        enabled: true
    },
    scrolling: {
                mode: "virtual"
    },
    paging: {
        pageSize: 10
    },
    groupPanel: {
        visible: true,
        placeholder: "Arrastre hasta aqui para agupar"
    },
    export: {
        enabled: true,
        fileName: "weekData"
    },
    editing: {
         mode: "batch",
      allowEditing: true,
        allowDeleting: true
    },
    summary: {
        totalItems: [{
            column: "Articulo",
            summaryType: "count"
        },  {
            column: "Cantidad",
            summaryType: "sum"
            
        }]
    }

}).dxDataGrid("instance");

$("#autoExpand").dxCheckBox({
    value: true,
    text: "Expand All Groups",
    onValueChanged: function (data) {
        dataGrid.option("grouping.autoExpandAll", data.value);
    }
});











var products = [];